# ⚡ INICIO RÁPIDO — VerbalIA en tu PC

## 1. Instalar Node.js (una sola vez)
Descarga la versión **LTS** de https://nodejs.org e instálala. Verifica en una terminal:
```bash
node -v    # v20 o superior
npm -v
```

## 2. Descomprimir el proyecto
Descomprime `verbalia.zip` donde quieras (por ejemplo `C:\Users\TuNombre\verbalia` o `~/verbalia`).

## 3. Instalar dependencias (una sola vez)
Abre una terminal dentro de la carpeta `verbalia` (en Windows: escribe `powershell` en la barra de direcciones del Explorador y pulsa Enter) y ejecuta:
```bash
npm install
```

## 4. Arrancar el juego
```bash
npm run dev
```
Abre **http://localhost:3000** — ¡listo! (Ctrl + C para detener; para volver a jugar otro día repite solo este paso).

## Probar el juego en 3 minutos
1. **Comenzar la aventura** → nombre, avatar, objetivo y experiencia.
2. **La prueba del faro**: 8 preguntas de nivelación (o «Saltar»).
3. En el panel: **«Sesión recomendada»** → tarjetas SRS.
4. Abre el **mapa**: Bosque (niv. 1), Ciudad (2), Fortaleza (3), Biblioteca (4), **Puerto de las Voces (5)** y **Torre de la Expresión (6)**.
5. En el Puerto: **Dictado del Faro** (escucha y escribe) y **Ecos del Puerto** (tono e intención).
6. En la Torre: **Historias Ramificadas**, **Sabiduría Popular** y el **Reto del Minuto**.
7. Falla algo a propósito → tu **cuaderno de errores** → «Practicar».
8. Recarga la página: el progreso sigue ahí (IndexedDB local).
9. En **Ajustes**: modo oscuro, **modo lectura nocturna**, tamaño de texto, reducir movimiento.

## Problemas frecuentes
| Problema | Solución |
|---|---|
| `npm` no se reconoce | Instala Node.js y abre una terminal nueva. |
| Puerto 3000 ocupado | `npm run dev -- -p 3001` → http://localhost:3001 |
| No oigo las voces | La síntesis de voz depende del navegador/sistema; el juego ofrece alternativa visual o «modo copia y acentúa». |
| Pantalla en blanco tras actualizar | DevTools (F12) → Application → Service Workers → Unregister, y recarga con Ctrl+Shift+R. |
| Quiero correr las 95 pruebas del motor | Instala Bun (https://bun.sh): `bun install && bun test`. También: `bun run scripts/audit-data.ts` (auditoría de datos). |

## Privacidad
Tu partida se guarda **solo en tu navegador**. Exporta/importa tu progreso desde **Perfil → Tus datos**. Sin cuentas, sin rastreadores.
