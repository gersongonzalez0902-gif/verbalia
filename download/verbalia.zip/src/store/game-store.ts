"use client";

/**
 * Store central del juego · Zustand.
 * Mantiene perfil, ajustes, núcleo de progreso y tarjetas SRS en memoria
 * y los persiste en IndexedDB (con guardado diferido y volcado inmediato
 * en los momentos críticos).
 */

import { create } from "zustand";
import type {
  AnswerRecord,
  GameSettings,
  PlayerProfile,
  SrsCard,
  SrsGrade,
  SessionSpec,
  SessionResult,
  SkillId,
} from "@/types";
import { createCore, reduceSessionComplete, computePlacement } from "@/engine/core";
import { reviewCard, newCard, isLearned, isMastered } from "@/engine/srs";
import { EMPTY_PROFILE, migrateProfile, migrateCore } from "@/engine/migrate";
import { applyPurchase, applyEquip } from "@/engine/shop";
import { applyArcadeUnlock, applyArcadeScore, applyChessElo } from "@/engine/arcade";
import { storage, CURRENT_SCHEMA_VERSION, type PersistedState } from "@/services/storage";
import { useMusicStore } from "@/services/music-station";
import { setSoundEnabled, setMusicVolume, setSfxVolume, setTtsRate, setHaptics } from "@/services/audio";

const SAVE_DEBOUNCE_MS = 700;

export const DEFAULT_SETTINGS: GameSettings = {
  reduceMotion: false,
  textSize: "md",
  sound: true,
  musicVolume: 0.55,
  sfxVolume: 0.9,
  dailyGoalXp: 120,
  newCardsPerDay: 8,
  offlineMode: true,
  nightMode: false,
  themeColor: "aurora",
  musicInGames: false,
  stationVolume: 0.75,
  stationInGames: false,
  ttsRate: 1,
  haptics: false,
};

export interface GameStore {
  hydrated: boolean;
  hasProfile: boolean;
  profile: PlayerProfile;
  settings: GameSettings;
  core: ReturnType<typeof createCore>;
  srs: Record<string, SrsCard>;
  lastResult: SessionResult | null;

  hydrate: () => Promise<void>;
  finishOnboarding: (profile: Omit<PlayerProfile, "createdAt" | "onboarded" | "placementDone">) => void;
  finishPlacement: (answers: { skill: SkillId; difficulty: number; correct: boolean }[]) => void;
  skipPlacement: () => void;
  completeSession: (spec: SessionSpec, answers: AnswerRecord[], durationMs: number) => SessionResult;
  rateCard: (wordId: string, grade: SrsGrade) => void;
  updateSettings: (partial: Partial<GameSettings>) => void;
  updateProfile: (partial: Partial<PlayerProfile>) => void;
  /** Compra un artículo del Bazar del Copista con tinta. */
  buyShopItem: (itemId: string) => "ok" | "sin-fondos" | "ya-propietario" | "escudo-lleno" | "item-desconocido";
  /** Equipa un marco o título ya comprado. */
  equipShopItem: (itemId: string) => void;
  /** Desbloquea un juego del Salón con tinta. */
  unlockArcade: (gameId: string) => "ok" | "sin-fondos" | "ya-desbloqueado" | "item-desconocido";
  /** Registra la puntuación de una partida del Salón (XP + tinta + récord). */
  recordArcadeScore: (gameId: string, score: number) => { xp: number; tinta: number; isRecord: boolean };
  /** Actualiza el ELO de ajedrez tras una partida contra el motor. */
  recordChessResult: (result: "w" | "d" | "l", engineElo: number) => void;
  resetAll: () => Promise<void>;
  /** Borra progreso (XP, niveles, logros, misiones, historial) conservando perfil y ajustes. */
  resetProgress: () => Promise<void>;
  /** Borra solo el jardín de tarjetas (SRS). */
  resetSrs: () => Promise<void>;
  exportJson: () => string | null;
  importJson: (text: string) => Promise<boolean>;
  clearLastResult: () => void;
}

const EMPTY_PROFILE_STORE: PlayerProfile = EMPTY_PROFILE;

let saveTimer: ReturnType<typeof setTimeout> | null = null;
let pendingSave = false;

function applySettingsSideEffects(settings: GameSettings) {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.textSize = settings.textSize;
  document.documentElement.dataset.theme = settings.themeColor ?? "aurora";
  document.documentElement.classList.toggle("reduce-motion", settings.reduceMotion);
  document.documentElement.classList.toggle("night", settings.nightMode);
  setSoundEnabled(settings.sound);
  setMusicVolume(settings.musicVolume);
  setSfxVolume(settings.sfxVolume);
  setTtsRate(settings.ttsRate ?? 1);
  setHaptics(Boolean(settings.haptics));
  useMusicStore.getState().setVolume(settings.stationVolume ?? 0.75);
}

export const useGameStore = create<GameStore>((set, get) => {
  const persist = (immediate = false) => {
    const { profile, settings, core, srs } = get();
    const state: PersistedState = {
      version: CURRENT_SCHEMA_VERSION,
      profile,
      settings,
      core,
      srs,
      savedAt: Date.now(),
    };
    pendingSave = true;
    const doSave = () => {
      pendingSave = false;
      void storage.save(state);
    };
    if (immediate) {
      if (saveTimer) clearTimeout(saveTimer);
      doSave();
      return;
    }
    if (saveTimer) clearTimeout(saveTimer);
    saveTimer = setTimeout(doSave, SAVE_DEBOUNCE_MS);
  };

  // Volcado al cerrar/ocultar la pestaña: nunca se pierde progreso.
  if (typeof window !== "undefined") {
    const flush = () => {
      if (!pendingSave) return;
      if (saveTimer) clearTimeout(saveTimer);
      const { profile, settings, core, srs } = get();
      void storage.save({ version: CURRENT_SCHEMA_VERSION, profile, settings, core, srs, savedAt: Date.now() });
      pendingSave = false;
    };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") flush();
    });
  }

  return {
    hydrated: false,
    hasProfile: false,
    profile: EMPTY_PROFILE,
    settings: DEFAULT_SETTINGS,
    core: createCore(),
    srs: {},
    lastResult: null,

    async hydrate() {
      const saved = await storage.load();
      if (saved && saved.profile) {
        const settings = { ...DEFAULT_SETTINGS, ...saved.settings };
        const profile = migrateProfile(saved.profile);
        set({
          hydrated: true,
          hasProfile: profile.onboarded,
          profile,
          settings,
          core: migrateCore(saved.core),
          srs: saved.srs ?? {},
        });
        applySettingsSideEffects(settings);
      } else {
        set({ hydrated: true, hasProfile: false });
        applySettingsSideEffects(DEFAULT_SETTINGS);
      }
    },

    finishOnboarding(profileData) {
      const profile: PlayerProfile = {
        ...profileData,
        createdAt: Date.now(),
        onboarded: true,
        placementDone: false,
      };
      set({ profile, hasProfile: true });
      persist(true);
    },

    finishPlacement(answers) {
      const { profile, core } = get();
      const skills = computePlacement(profile.experience, answers);
      set({
        profile: { ...profile, placementDone: true },
        core: { ...core, skills },
      });
      persist(true);
    },

    skipPlacement() {
      const { profile } = get();
      set({ profile: { ...profile, placementDone: true } });
      persist(true);
    },

    completeSession(spec, answers, durationMs) {
      const { core, srs } = get();
      const cards = Object.values(srs);
      const learned = cards.filter(isLearned).length;
      const mastered = cards.filter(isMastered).length;
      const { core: nextCore, result } = reduceSessionComplete(core, {
        spec,
        answers,
        durationMs,
        now: new Date(),
        masteredWords: mastered,
        learnedWords: learned,
      });
      set({ core: nextCore, lastResult: result });
      persist(true); // Fin de sesión: guardado inmediato.
      return result;
    },

    rateCard(wordId, grade) {
      const { srs } = get();
      const card = srs[wordId] ?? newCard(wordId, Date.now());
      const updated = reviewCard(card, grade, Date.now());
      set({ srs: { ...srs, [wordId]: updated } });
      persist(); // diferido: las ráfagas de tarjetas no bloquean la UI
    },

    updateSettings(partial) {
      const settings = { ...get().settings, ...partial };
      set({ settings });
      applySettingsSideEffects(settings);
      persist(true);
    },

    updateProfile(partial) {
      const profile = { ...get().profile, ...partial };
      set({ profile });
      persist(true);
    },

    buyShopItem(itemId) {
      const outcome = applyPurchase(get().core, itemId);
      if (!outcome.ok || !outcome.core) return outcome.reason ?? "item-desconocido";
      set({ core: outcome.core });
      persist(true);
      return "ok";
    },

    equipShopItem(itemId) {
      const core = applyEquip(get().core, itemId);
      set({ core });
      persist(true);
    },

    unlockArcade(gameId) {
      const outcome = applyArcadeUnlock(get().core, gameId);
      if (!outcome.ok || !outcome.core) return outcome.reason ?? "item-desconocido";
      set({ core: outcome.core });
      persist(true);
      return "ok";
    },

    recordArcadeScore(gameId, score) {
      const outcome = applyArcadeScore(get().core, gameId, score);
      set({ core: outcome.core });
      persist(true);
      return { xp: outcome.xp, tinta: outcome.tinta, isRecord: outcome.isRecord };
    },

    recordChessResult(result, engineElo) {
      const core = applyChessElo(get().core, result, engineElo);
      set({ core });
      persist(true);
    },

    async resetAll() {
      await storage.clear();
      set({
        hasProfile: false,
        profile: EMPTY_PROFILE_STORE,
        settings: DEFAULT_SETTINGS,
        core: createCore(),
        srs: {},
        lastResult: null,
      });
      applySettingsSideEffects(DEFAULT_SETTINGS);
    },

    async resetProgress() {
      const core = createCore();
      set({ core, lastResult: null });
      persist(true);
    },

    async resetSrs() {
      set({ srs: {} });
      persist(true);
    },

    exportJson() {
      const { profile, settings, core, srs } = get();
      return storage.export({ version: CURRENT_SCHEMA_VERSION, profile, settings, core, srs, savedAt: Date.now() });
    },

    async importJson(text) {
      const parsed = storage.parseImport(text);
      if (!parsed) return false;
      const profile = migrateProfile(parsed.profile);
      set({
        profile,
        settings: { ...DEFAULT_SETTINGS, ...parsed.settings },
        core: migrateCore(parsed.core),
        srs: parsed.srs ?? {},
        hasProfile: profile.onboarded,
      });
      applySettingsSideEffects({ ...DEFAULT_SETTINGS, ...parsed.settings });
      const migrated = {
        version: CURRENT_SCHEMA_VERSION,
        profile,
        settings: { ...DEFAULT_SETTINGS, ...parsed.settings },
        core: migrateCore(parsed.core),
        srs: parsed.srs ?? {},
        savedAt: Date.now(),
      };
      await storage.save(migrated);
      return true;
    },

    clearLastResult() {
      set({ lastResult: null });
    },
  };
});
